function succ=zxhWhsRegIntLab(strAtlasFilename, strLabelFilename, strImageFilename, strPreviousSegAndProbImages, strT2Aff, strT1Ffd, strPreSave, strType)  
% author: Xiahai Zhuang
% date of creation:   2014-11-20
% current version: 2.0  
%	succ=zxhWhsIntLab(strAtlasFilename, strLabelFilename, strImageFilename, strPreviousSegAndProbImages, strPreSave, strType)   
%        resulting T1 X T2, i.e. T2(T1(x)), from image to atlas  
%     strPreviousSegAndProbImages:   strPreviousSegAndProbImages{1} is label, 2:bk, 3:myo, 4:[420, 500, 550, 600, 820, 850];
%     strType:   
%        '-noprob-'        (first iteration, no prob images)  
%        '-probnoT-'       (second iteration, with prob images, no T1/T2)  
%        '-probT-'         (default, after 2 iterations, with prob images and T1 T2)   
disp(' ---------------------------------------------------------------------');
disp(' -  This is testing code and not free from bugs. The software is for -');
disp(' -  research purpose ONLY, and should NOT be used in any clinical    -');
disp(' -  related situations. Any usage is entirely at your own risk.      -');
disp(' -         ZHUANG, Xiahai  (zhuangxiahai@163.com)                    -');
disp(' ---------------------------------------------------------------------');
%   
verbose=' -v 0 ';

%disp([DATESTR(NOW) ': zxhWhsRegIntLab( ' strAtlasFilename ', ' strLabelFilename ', ' strImageFilename ', ' strPreviousSegAndProbImages ', ' strPreSave ', ' strType ')']);  

if isempty(strfind(strType,'-noprob-'))==0, % first ite -------------------- T1.AFF, T2.FFD
	succ=zxhwhscta(strAtlasFilename, strLabelFilename, strImageFilename, strPreSave, '-transform-');
	return ;
end

if isempty(strfind(strType,'-probnoT-'))==0, % 2nd ite -------------------- T1.FFD, T2.AFF
% idea 2015-2-3:
% Max(P(L|I,An)=Max(P(An|I;L)/P(An|I))-->Max(P(An|I;L)), as
% P(An|I)==MI(An,I) has been done in first iteration. And,
% Max(P(An|I;L))==Max(MI(An,I)), s.t., Max(L(posterio),Ln)==
% (1) T2=min(Posterior-Patlas)^2; (2) T1=Max(MI(T2(An),I)); (3) T=T1xT2
	system(['zxhreg -test ' strPreviousSegAndProbImages{1} ' -ref ' strLabelFilename ' -pre 13 -sub 4 4 4 -steps 200 -aff -o ' strPreSave 'T2 -notsaveimage ']);
	system(['zxhtransform ' strPreviousSegAndProbImages{1} ' ' strLabelFilename ' -o ' strPreSave '__ -n 1 -t ' strPreSave 'T2.AFF -nearest ']);
	system(['zxhvolumelabelop ' strPreSave '__.nii.gz  ' strPreSave '__ -rmnonwh ']); 
	system(['zxhvolumelabelop ' strPreSave '__.nii.gz  ' strPreSave '__T2AtProb -genprob 3 -whs ']); 
	% loc aff reg, fuse locaff 2 ffd, call zxhWhsRegIntLab, delete __*
	labs=[420, 500, 550, 600, 820, 850]; %strPreviousSegAndProbImages4-9
	strLocRegions=' ';
	strLocAffs=' ';
	for i=1:6
		system(['zxhreg -test ' strPreviousSegAndProbImages{i+3} ' -ref ' strPreSave '__T2AtProb_Label' num2str(labs(i)) '.nii.gz ' ...
			' -pre 13 -sub 4 4 4 -steps 200 -aff -o ' strPreSave '__Label' num2str(labs(i)) ' -ssd notsaveimage -v 0 ']);
		system(['zxhimageop -int ' strPreviousSegAndProbImages{1} ' -o ' strPreSave '__Label' num2str(labs(i)) ' -vr ' num2str(labs(i)) ' ' num2str(labs(i)) ' -VS ' num2str(labs(i)) verbose]);
		strLocRegions=[strLocRegions ' ' strPreSave '__Label' num2str(labs(i)) '.nii.gz '];
		strLocAffs=[strLocAffs ' ' strPreSave '__Label' num2str(labs(i)) '.AFF '];
	end 
  command=['zxhtransformvector ' strPreviousSegAndProbImages{1} ' -o ' strPreSave '__ -n 1 -loc 6 ' strLocRegions ' -locaff 6 ' strLocAffs ' -savenewAFFS ' verbose]; system(command);
  command=['zxhtransformop -fuseaffs ' strPreSave '__.AFFS ' strPreviousSegAndProbImages{1} ' ' strPreSave '__.FLD 7 ' verbose]; system(command);  

  command=['zxhffdapprox ' strPreSave '__.FLD ' strPreSave 'T1.FFD 20 20 20 -level 2 ' verbose]; system(command);
	succ=zxhWhsRegIntLab(strAtlasFilename, strLabelFilename, strImageFilename, strPreviousSegAndProbImages, [strPreSave 'T2.AFF'], [strPreSave 'T1.FFD'], strPreSave, '-probT-');
	delete([strPreSave '__*'] );  
	return ;
end

% if isempty(strfind(strType,'-probT-')), % default, after 2ite
if exist([strPreSave '__T2AtProb_Label0.nii.gz'], 'file')==0,
  system(['zxhtransform ' strPreviousSegAndProbImages{1} ' ' strLabelFilename ' -o ' strPreSave '__ -n 1 -t ' strT2Aff ' -nearest ' verbose]);
	system(['zxhvolumelabelop ' strPreSave '__.nii.gz  ' strPreSave '__ -rmnonwh ' verbose]); 
	system(['zxhvolumelabelop ' strPreSave '__.nii.gz  ' strPreSave '__T2AtProb -genprob 3 -whs ' verbose]); 
end
labs=[205, 420, 500, 550, 600, 820, 850]; %strPreviousSegAndProbImages3-9
strMimgTest=' ';  strMimgRef=' '; 
for i=1:7
	strMimgRef=[strMimgRef ' ' strPreSave '__T2AtProb_Label' num2str(labs(i)) '.nii.gz ']; 
	strMimgTest=[strMimgTest ' ' strPreviousSegAndProbImages{i+2}];
	system(['zxhimageop -int '  strPreSave '__T2AtProb_Label' num2str(labs(i)) '.nii.gz ' ' -int ' strPreviousSegAndProbImages{i+2} ' -o ' strPreSave '__Label' num2str(labs(i)) '.nii.gz' ' -sum ' verbose]);
	strMimgMaskT{i}=[strPreSave '__Label' num2str(labs(i)) '.nii.gz'];
end
strT2AffAtlas=[strPreSave 'T1.nii.gz'];
system(['zxhtransform ' strImageFilename ' ' strAtlasFilename ' -o ' strT2AffAtlas ' -n 1 -t ' strT2Aff verbose]);
command=['zxhsemi0 -test ' strImageFilename ' -ref ' strT2AffAtlas ' -o ' strPreSave 'T1 ' ' -bending 0.002 -ffd 20 20 20 -ffd 10 10 10 -sub 4 4 4 -sub 2 2 2 ' ...
	' -Reg 2 -steps 50 20 -length 2 1 -pre 0 ' strT1Ffd ' -mimg 7 ' strMimgTest ' ' strMimgRef ' 0.2 0.2 0.2 0.2 0.2 0.2 0.2 ' ...
	' -mimgmaskt 1 ' strMimgMaskT{1} ' -mimgmaskt 2 ' strMimgMaskT{2} ' -mimgmaskt 3 ' strMimgMaskT{3} ' -mimgmaskt 4 ' strMimgMaskT{4} ... 
	' -mimgmaskt 5 ' strMimgMaskT{5} ' -mimgmaskt 6 ' strMimgMaskT{6} ' -mimgmaskt 7 ' strMimgMaskT{7} ]; system(command);
delete([strPreSave '__*'] );  
succ='success';
return ;
end

 



