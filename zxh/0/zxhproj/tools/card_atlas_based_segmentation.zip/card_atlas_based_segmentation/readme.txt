
* a whole heart atlas, with MR intensity image and label image
* script in matlab: zxhwhs.m
* the scripts and binary tools that zxhwhs.m needs
 
  matlas scripts:
	zxhWhsGenLocRegion.m 
	zxhWhsTarget2AtlasRegAffine.m 
	zxhWhsRegIntLab.m
	zxhWhsRegLab.m
	
  binary tools from zxhproj:
	zxhboundary
	zxhffdapprox
	zxhimageop
	zxhInitPreTransform
	zxhreg
	zxhreglarm
	zxhregsemi0
	zxhregsemi
	zxhtransform
	zxhtransformvector 
	zxhvolumelabelop
	
* related papers 

Atlas-based and multi-atlas segmentation:
  "X Zhuang and J Shen: Multi-scale patch and multi-modality atlases for whole heart segmentation of MRI, Medical Image Analysis, vol.31, pp.77–87, 2016" 
  "X Zhuang, W Bai, J Song, S Zhan, X Qian, W Shi, Y Lian, D Rueckert: Multiatlas whole heart segmentation of CT data using conditional entropy for atlas ranking and selection. Medical Physics 42 (7), 3822-3833, 2015"
  "Zhuang, X., Rhode, K., Razavi, R., Hawkes, D. J., Ourselin, S.: A Registration-Based Propagation Framework for Automatic Whole Heart Segmentation of Cardiac MRI. IEEE Transactions on Medical Imaging, 29 (9): 1612-1625, 2010."

Registration:
  (1) "Zhuang, X., Arridge, S., Hawkes, D. J., Ourselin, S.: A Nonrigid Registration Framework Using Spatially Encoded Mutual Information and Free-Form Deformations, IEEE Transactions on Medical Imaging, 30(10): 1819-1828, 2011."
  (2) "Zhuang, X., Hawkes, D. J., Ourselin, S.: Unifying encoding of spatial information in mutual information for nonrigid registration. International conference on Information Processing in Medical Imaging (IPMI), Lecture Notes in Computer Science, 5636: 491-502, 2009."
  (3) "Zhuang, X., Rhode, K., Razavi, R., Hawkes, D. J., Ourselin, S.: A Registration-Based Propagation Framework for Automatic Whole Heart Segmentation of Cardiac MRI. IEEE Transactions on Medical Imaging, 29 (9): 1612-1625, 2010."
  (4) "Zhuang, X., Rhode, K., Arridge, S., Razavi, R., Hill, D., Hawkes, D. J., Ourselin, S.: An atlas-based segmentation propagation framework using locally affine registration-Application to automatic whole heart segmentation. International Conference on Medical Image Computing and Computer Assisted Intervention (MICCAI), 5242: 425-433, 2008."

