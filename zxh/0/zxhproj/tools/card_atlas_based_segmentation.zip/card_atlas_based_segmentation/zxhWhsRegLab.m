function succ=zxhWhsRegLab(strLabelTarget, strLabelSource, strPreSave, strType)  
% author: Xiahai Zhuang
% date of creation:   2015-08-06
% current version: 2.0  
%	succ=succ=zxhWhsRegLab(strLabelTarget, strLabelSource, strPreSave, strType)   
%     strType:   
%        '-rig-'        (only rigid registration, .AFF)  
%        '-aff-'        (only affine registration, .AFF)  
%        '-larm-'       (only reg aff+larm, .FFD, .AFF)  
%        '-ffd-'        (default, aff+larm+ffd, where ffd use -whs)   
disp(' ---------------------------------------------------------------------');
disp(' -  This is testing code and not free from bugs. The software is for -');
disp(' -  research purpose ONLY, and should NOT be used in any clinical    -');
disp(' -  related situations. Any usage is entirely at your own risk.      -');
disp(' -         ZHUANG, Xiahai  (zhuangxiahai@163.com)                    -');
disp(' ---------------------------------------------------------------------');
%   
verbose=' -v 0 '; imagetype='nii.gz';

%disp([DATESTR(NOW) ': zxhWhsRegIntLab( ' strAtlasFilename ', ' strLabelFilename ', ' strImageFilename ', ' strPreviousSegAndProbImages ', ' strPreSave ', ' strType ')']);  
tar2mm=[strPreSave '__tar2mm.nii.gz']; system(['zxhtransform ' strLabelTarget ' -o ' tar2mm ' -resave -spacing 2 2 2 -nearest ' verbose ]);
src2mm=[strPreSave '__src2mm.nii.gz']; system(['zxhtransform ' strLabelSource ' -o ' src2mm ' -resave -spacing 2 2 2 -nearest ' verbose ]);
affrig=' -aff ' ; 
if isempty(strfind(strType,'-rig-'))==0, affrig=' -rig ' ; end

affcommand=['zxhreg -test ' tar2mm ' -ref ' src2mm ' -o ' strPreSave ' -notsaveimage -smoothr 4 -smootht 4 ' ...
	          affrig ' -length 2 1 -sub 6 6 6 -sub 4 4 4 -steps 200 100 -Reg 2 -cc ' verbose] ; 
system(affcommand) ; 

if isempty(strfind(strType,'-aff-')) && isempty(strfind(strType,'-rig-')) , % do larm
	zxhWhsGenLocRegion(tar2mm, strPreSave);	 
	LA=[strPreSave 'LA.' imagetype];	RA=[strPreSave 'RA.' imagetype]; RV=[strPreSave 'RV.' imagetype]; LV=[strPreSave 'LV.' imagetype];  
	LO=[strPreSave 'LO.' imagetype];	DO=[strPreSave 'DO.' imagetype]; RP=[strPreSave 'RP.' imagetype];  
	Mask=[strPreSave 'Mask.' imagetype];
	system(['zxhtransform ' tar2mm ' ' strLabelSource ' -o ' src2mm ' -n 1 -t ' strPreSave '.AFF -nearest ' verbose]);
  larmcommand=['zxhreglarm -test ' tar2mm ' -ref ' src2mm ' -maskt ' Mask ' -smoothr 4 -smootht 4 -o ' strPreSave ' -notsaveimage -Reg 4 -steps 50 -length 2 1 -locaff ' ...
		           '-sub 4 4 4 -shape 0.1 -localmatrix 7 -localregions ' LA ' ' RA ' ' LO ' ' RP ' ' LV ' ' RV ' ' DO ' -gddis 10 -gddis 10 -gddis 10 -gddis 10 -gddis 10 -gddis 10  -gddis 10 '] ;
  system(larmcommand); 
  command=['zxhffdapprox ' strPreSave '.FLD ' strPreSave '.FFD 20 20 20 -level 2 ' verbose]; system(command);

	if isempty(strfind(strType,'-larm-')), % do ffd
		system(['zxhtransform ' strLabelTarget ' ' strLabelSource ' -o ' src2mm ' -n 1 -t ' strPreSave '.AFF -nearest ' verbose]); 
    ffdcommand=['zxhregsemi0 -test ' tar2mm ' -ref ' src2mm ' -o ' strPreSave ' -pre 0 ' strPreSave '.FFD -bending 0.001 -maskt ' WH ' -masktdi 20 -smoothr 2 -smootht 2 '  
			          ' -ffd 20 20 20 -ffd 10 10 10 -steps 200 100 50 -length 3 2 1 -sub 4 4 4 -sub 3 3 3 -sub 2 2 2 ' verbose];
		system(ffdcommand);
	end
	zxhWhsGenLocRegion('-clear-', strPreSave);
end
 
delete(tar2mm, src2mm);
end


