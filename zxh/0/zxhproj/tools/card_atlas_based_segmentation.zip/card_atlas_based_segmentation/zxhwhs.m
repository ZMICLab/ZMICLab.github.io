function succ=zxhwhs(strAtlasFilename, strLabelFilename, strImageFilename, strPreSave, strType, args)  
%SegmentType=strType��eg: '-mr-roi-
% author: Xiahai Zhuang
% date of creation:   2015-6-03
% current version:  
%	succ=zxhwhs(strAtlasFilename, strLabelFilename, strImageFilename, strPreSave, strType, args ) 
%     Type: NOTE providing preaffine or roi is very important in successful WHS
%        '-preaffine-'     (affine registration is pre-performed, from atlas to image, affine=args) 
%        '-preseg-'        (label images used for affine reg, init for global affine registration, preseg=args) 
%        '-roi-'           (roi of target image, used for init in global affine registration, roi=args)   
%        '-ctmr-'          (MRI and CTA, cross modality)  
%        '-mr-'            (whs of MRI)  
%        '-cc-'            (cross correlation as similarity) 
%        '-fast-'          (cross correlation as similarity) 
% gives T1.AFF X T2.FFD, i.e. T2(T1(x)), from image to atlas
%   work for cta-mri, Mspace = label+DI30mm

xlstimeaff=[];%computationtime_affRaS.xls';����ʱ��
xlstimeaps=[];%computationtime_atlasReg.xls';
xlstimedefreg=[];%computationtime_DefReg.xls'; 
if nargin <=5, args=''; end

mrheart = ' '; % not boundary between RV & septum -heart in CTA     RV���ķ�
if isempty(strfind(strType,'-mr-')) == 0 , % is whs of mr 	
    mrheart = ' -heart ' ; 
end
PreviousSeg='';  % for larm, currently useless 
imagetype='nii.gz' ;   verbose=' -v 0 ' ;  %' -v 0 ' ��������Լ������Ĺ��������һ��С���ܣ������˼���ǲ�Ҫ����м�����˵��
verboseno=' -v 0 ' ; deleteall=1; metric=' -MIIB 5 -200 1800 ' ; % for both CCTA and CMRI
Intensity=strAtlasFilename; Label=strLabelFilename; Image=strImageFilename;  
PreSave=strPreSave; SegmentType=strType;
newfolder=[PreSave '__atlas'] ; locfolder=newfolder;
 
if isempty(strfind(strType,'-cc-'))==0,
  metric=' -cc ' ;
end
if exist(Image,'file')==0,
	disp( 'error and fail can not find Image for segmentation ! '); 	succ='failure' ; return; end ;  
if exist(Label, 'file')==0,
	disp( 'error and fail can not find Label for segmentation ! '); 	succ='failure' ; return; end ;  
if exist(Intensity, 'file')==0,  
	echo 'error and fail can not endnd Intensity for segmentation ! ';  succ='failure' ; return; end ;   
if isempty(strfind(SegmentType,'-track-'))==0, deleteall=0 ; 	verbose=' -v ' ; end
if isempty(strfind(SegmentType,'-deleteall-'))==0, deleteall=1 ; 	verbose=' -v 0 ' ; end %�����д����Ŀ����ʲô�أ���

  
U=[locfolder 'U.' imagetype];	D=[locfolder 'D.' imagetype];
LA=[locfolder 'LA.' imagetype];	RA=[locfolder 'RA.' imagetype]; RV=[locfolder 'RV.' imagetype]; LV=[locfolder 'LV.' imagetype];  
LO=[locfolder 'LO.' imagetype];	DO=[locfolder 'DO.' imagetype]; RP=[locfolder 'RP.' imagetype]; WH=[locfolder 'WH.' imagetype];
Mask=[locfolder 'Mask.' imagetype];
FFDsMaskBlood=[locfolder 'MaskForFFDsBlood.' imagetype]; 	
FFDsMaskFiner=[locfolder 'MaskForFFDsFiner.' imagetype];  
  
% %%%%  region and mask images end %%%% % 
 

 %%% % CLASSAM LARM % %%%  larm3(U, D, DO), larm6 -shape 0.01 (no DO for MR atlas)
LocAffRoi=[' notsaveimage -Reg 4 -steps 50 -length 2 1 -locaff ' metric ] ; 
if isempty(strfind(strType,'-fast-'))==0,
  LocAffRoi=[' notsaveimage -Reg 2 -steps 30 -length 2 2 -locaff ' metric ] ;
end
%system(['zxhimageop -int ' WH ' -CL 5 -v 0 ']); system(['zxhimageop -int ' WH ' -ER 4 -v 0 ']); 
larm2=[LocAffRoi ' -sub 4 4 4 -shape 0.001 -savelocalaffines -localmatrix 2 -localregions ' WH ' ' DO ' -gddis 10  -gddis 15 '] ; 
larm3=[mrheart LocAffRoi ' -sub 4 4 4 -shape 0.01 -savelocalaffines -localmatrix 3 -localregions ' U ' ' D ' ' DO ' -gddis 15  -gddis 15  -gddis 15 '] ; 
  % experience 2011-Feb-1 -Reg 4 for larm7 is far more important than a larm4 ; 
  % savenameINV.FLD
larm7=[mrheart LocAffRoi '-sub 4 4 4 -shape 0.1  -computeinverse -localmatrix 7 -localregions ' LA ' ' RA ' ' LO ' ' RP ' ' LV ' ' RV ' ' DO ' -gddis 10 -gddis 10 -gddis 10 -gddis 10 -gddis 10 -gddis 10  -gddis 10 '] ;

 %%% % bending energy could help maintain the epicardium(����Ĥ�� in ffd1(???)
bending=' -bending 0.002 ';
mi=[' notsaveimage ' bending  metric];  % first reg for regularization of FFD mesh
FFD1=[' ' mi ' -ffd 20 20 20 -sub 4 4 4 -steps 200 -length 3 '] ;  
FFD2=[' ' mi ' -ffd 20 20 20 -ffd 10 10 10 -sub 4 4 4 -sub 2 2 2 -Reg 2 -steps 100 50 -length 2 1 '] ;
if isempty(strfind(strType,'-fast-'))==0,
  FFD1=[' ' mi ' -ffd 20 20 20 -sub 4 4 4 -steps 100 -length 3 '] ;  
  FFD2=[' ' mi ' -ffd 20 20 20 -ffd 10 10 10 -sub 4 4 4 -sub 2 2 2 -Reg 2 -steps 50 30 -length 2 1 '] ;
end 

% ---------------- step 0: prepare Mspace and generate local regions ---------------- %
Mspace2mm=[PreSave '__step1label2mm.' imagetype] ; 
command=['zxhtransform ' Label     ' -o ' Mspace2mm ' -resave -spacing 2 2 2 -nearest ' verboseno]; system(command);  
command=['zxhvolumelabelop ' Mspace2mm  ' ' Mspace2mm ' -gvoutrange ' verboseno]; system(command);
command=['zxhvolumelabelop ' Mspace2mm  ' ' Mspace2mm ' -rmnonwh ' verboseno]; system(command); 
command=['zxhtransform ' Mspace2mm  ' -o ' Mspace2mm ' -addroi 15 15 15 15 15 15  ' verboseno]; system(command); 
if isempty(strfind(strType,'-fast-'))==0,
  command=['zxhimageop -int ' Mspace2mm  ' -o ' Mspace2mm ' -DI 10 ' verboseno]; system(command); % 20mm
else
  command=['zxhimageop -int ' Mspace2mm  ' -o ' Mspace2mm ' -DI 15 ' verboseno]; system(command); % 30mm
end
command=['zxhtransform ' Mspace2mm  ' -o ' Mspace2mm ' -cropmask ' verboseno]; system(command);
 
	% prepare images step 1 ---- resample and intensity range
Label2mm=Mspace2mm; % remove outrange nonwh
Atlas2mm=[PreSave '__step1atlas2mm.' imagetype];
Mprevseg2mm=[PreSave '__Mprevseg2mm.' imagetype]; % remove outrange nonwh
command=['zxhtransform ' Mspace2mm ' ' Intensity ' -o ' Atlas2mm ' -bg ' verboseno]; system(command) ;
command=['zxhtransform ' Mspace2mm ' ' Label ' -o ' Label2mm ' -nearest ' verboseno]; system(command) ;

zxhWhsGenLocRegion(Label2mm,newfolder);	 
%disp( 'Finish generate local regions'); 
	  
% Initialisation transformation from Atlas to Image: T, and its inverse transformation T'
% 1) Atlas2Image_GlobleAffine: G and its inverse transformation: G'
% 2) Atlas2Image_LocalAffine : L and its inverse transformation: L'
% Hence, X=T(Y)=G(L(Y)), and Y=T'(X)=L'(G'(X))

% %%%%% 1  Segment the unseen image which is transformed affinely to atlas space %%%%%
%disp( DATESTR(NOW));  seconds=timecost(6)+timecost(5)*60+timecost(4)*3600+timecost(3)*3600*24

PreSaveAff=[PreSave '__Atlas2Image']; 

timefrom=clock; 
succ=zxhWhsTarget2AtlasRegAffine(Image, Intensity, Label, PreSaveAff, [strType '-atlas2target-'], args) ;  
timecost=clock-timefrom; 
disp(['FINISH --- affine reg, has cost ' num2str(timecost(6)+timecost(5)*60+timecost(4)*3600+timecost(3)*3600*24) ' seconds']);

if isempty(xlstimeaff)==0, xlsid=fopen(xlstimeaff,'a');  fprintf(xlsid, ['AffineReg\t' datestr(timefrom) '\t to\t' datestr(timetoaff) '\t' num2str(etime(timetoaff,timefrom)) '\n']); fclose(xlsid);  end
if exist([PreSaveAff '.AFF'],'file')==0,
	disp( 'error and fail in global affine registration for localisation' );  return ; 
end

 % G': transform all unseen image into atlas space using G, and transform back using G'(MTX)
Mimage2mm=[PreSave '__Mimage2mm.' imagetype];   % Mprevseg2mm    
command=['zxhtransform ' Mspace2mm ' ' Image ' -o ' Mimage2mm ' -n 1 -t ' PreSaveAff '.AFF -bg -linear ' verboseno]; system(command);
command=['zxhimageop -int ' Mimage2mm ' -boundrange -200 1800 ' verboseno]; system(command);
timefrom=clock; 
if exist(PreviousSeg,'file')~=0, 
    % init LA ' ' RA ' ' LO ' ' RP ' ' LV ' ' RV
    command=['zxhtransform ' Label2mm ' ' PreviousSeg ' -o ' Mprevseg2mm ' -n 1 -t ' PreSaveAff '.AFF -nearest ' verboseno]; system(command); 
    command=['zxhvolumelabelop ' Mprevseg2mm  ' ' Label2mm ' -gvoutrange ' verboseno]; system(command);
    command=['zxhvolumelabelop ' Mprevseg2mm  ' ' Label2mm ' -rmnonwh ' verboseno]; system(command);
    vlab={'420', '550', '820', '850', '500', '600'};    
    for ir=1:6
        command=['zxhimageop -int ' Label2mm ' -o ' PreSave '__templctest.nii.gz -vr ' vlab{ir} ' ' vlab{ir} ' -VS ' vlab{ir} ' -v 0 ']; system(command);
        command=['zxhimageop -int ' Mprevseg2mm ' -o ' PreSave '__templcref.nii.gz -vr ' vlab{ir} ' ' vlab{ir} ' -VS ' vlab{ir} ' -v 0 ']; system(command);
        command=['zxhreg -notsaveimage -test ' PreSave '__templctest.nii.gz -ref ' PreSave '__templcref.nii.gz -scale -dr 0 -smootht 6 -smoothr 6 -o ' PreSave '__larmpre' vlab{ir} ' -steps 200 -sub 4 4 4 -v 0']; system(command);
    end
    larmpre=['-locpre 0 ' PreSave '__larmpre' vlab{1} '.AFF ' PreSave '__larmpre' vlab{2} '.AFF ' PreSave '__larmpre' vlab{3} '.AFF ' PreSave '__larmpre' vlab{4} '.AFF ' PreSave '__larmpre' vlab{5} '.AFF ' PreSave '__larmpre' vlab{6} '.AFF '];
    command=['zxhreglarm -test ' Atlas2mm ' -ref ' Mimage2mm ' -maskt ' Mask ' -o ' PreSave '__Atlas2Mimage_larm ' larm6  larmpre verbose];
    system(command);
    for ir=1:6 , delete([PreSave '__larmpre' vlab{ir} '.AFF']);   end
    delete([PreSave '__templctest.nii.gz'], [PreSave '__templcref.nii.gz']); 
else %  without prevseg for init 
    %command=['zxhreglarm -test ' Atlas2mm ' -ref ' Mimage2mm ' -maskt ' Mask ' -o ' PreSave '__Atlas2Mimage_larm ' larm2  verbose]; %WH DO
    %system(command); 
    larmpre='';%[' -locpre 0 ' PreSave '__Atlas2Mimage_larm_0.AFF ' PreSave '__Atlas2Mimage_larm_0.AFF ' PreSave '__Atlas2Mimage_larm_1.AFF ' ];
    command=['zxhreglarm -test ' Atlas2mm ' -ref ' Mimage2mm ' -maskt ' Mask ' -o ' PreSave '__Atlas2Mimage_larm ' larm3  larmpre verbose]; %U D DO
    system(command); 
    larmpre=[' -locpre 0 ' PreSave '__Atlas2Mimage_larm_0.AFF ' PreSave '__Atlas2Mimage_larm_0.AFF ' PreSave '__Atlas2Mimage_larm_0.AFF ' PreSave '__Atlas2Mimage_larm_0.AFF ' ...
      PreSave '__Atlas2Mimage_larm_1.AFF ' PreSave '__Atlas2Mimage_larm_1.AFF ' PreSave '__Atlas2Mimage_larm_2.AFF '];
    command=['zxhreglarm -test ' Atlas2mm ' -ref ' Mimage2mm ' -maskt ' Mask ' -o ' PreSave '__Atlas2Mimage_larm ' larm7  larmpre verbose]; 
    system(command);
end

timecost=timecost+clock-timefrom;   
disp(['FINISH --- larm reg, has cost ' num2str(timecost(6)+timecost(5)*60+timecost(4)*3600+timecost(3)*3600*24) ' seconds']);
  % ************ Mimage2mm: spacing 2x2x2, small ROI ************* %
command=['zxhtransformvector ' Mimage2mm ' -o ' PreSave '__Mimage2Atlas -fld -n 1 -t ' PreSave '__Atlas2Mimage_larmINV.FLD ' verbose]; 
system(command);
 
% %%%%% 3 adaptive FFD %%%%%%

ffdpre=[' -pre 0 ' PreSave '__Mimage2Atlas.FFD '] ;
command=['zxhffdapprox ' PreSave '__Mimage2Atlas.FLD ' PreSave '__Mimage2Atlas.FFD 20 20 20 -level 2 ' verbose]; system(command);

  % smooth label image
command=['zxhimageop -int ' Label2mm ' -gau 6 -v 0 ']; system(command); 
if exist( Mprevseg2mm, 'file' ) ~= 0, 
    system(['zxhimageop -int ' Mprevseg2mm ' -gau 6 -v 0']); 
end
ffdregimages=[' -test ' Mimage2mm ' -ref ' Intensity ' -maskr ' Mask ffdpre ' -o ' PreSave '__Mimage2Atlas ']; 
ffdmimg='';
timefrom=clock;
if isempty(FFD1)~=1 % not empty
    if exist(Mprevseg2mm,'file')~=0, % PreviousSeg,  
        ffdmimg=[' -mimg 1 ' Mprevseg2mm ' ' Label2mm ' 0.5 '];
    end
    command=['zxhregsemi0 ' ffdregimages ffdmimg FFD1 ' -ffdmaskr ' FFDsMaskBlood ' 0 ' verboseno];  system(command);
end  
if isempty(FFD2)~=1
    if exist(Mprevseg2mm,'file')~=0, % PreviousSeg,  
         ffdmimg=[' -mimg 1 ' Mprevseg2mm ' ' Label2mm ' 0.2 '];
    end
    command=['zxhregsemi0 ' ffdregimages ffdmimg FFD2 ' -ffdmaskr ' FFDsMaskFiner ' 0 ' verboseno];  system(command); 
end 
 
timecost=timecost+clock-timefrom;   
disp(['FINISH --- ffd reg, has cost ' num2str(timecost(6)+timecost(5)*60+timecost(4)*3600+timecost(3)*3600*24) ' seconds']); 


if isempty(xlstimeaps)==0,
    xlsid=fopen(xlstimeaps,'a'); 
    fprintf(xlsid, ['AtlasReg\t' datestr(timefrom) '\t to\t' datestr(timeto) '\t' num2str(etime(timeto,timefrom)) '\n']);
    fclose(xlsid);  
end
if isempty(xlstimedefreg)==0,
    xlsid=fopen(xlstimedefreg,'a');
    fprintf(xlsid, ['LarmFFDReg\t' datestr(timefromdef) '\t to\t' datestr(timeto) '\t' num2str(etime(timeto,timefromdef)) '\n']); 
    fclose(xlsid);  
end
 
% generate T1(AFF) and T2(FFD)
command=['zxhtransformvector ' LV ' -o ' PreSave 'T1 -n 1 -t ' PreSaveAff '.AFF -inv 1 ' verbose]; system(command);
movefile([PreSave '__Mimage2Atlas.FFD'],[PreSave 'T2.FFD']) ;
% generate result 
command=['zxhtransform ' strImageFilename ' ' strLabelFilename ' -o '  PreSave ' -n 2 -t ' PreSave 'T1.AFF -t ' PreSave 'T2.FFD -nearest -v 0 '];
system(command);

 
if deleteall ==  1,
    zxhWhsGenLocRegion('-clear-',newfolder);	 
    delete( [PreSave '__*'] );  
end
   
succ='success' ; 
end












 