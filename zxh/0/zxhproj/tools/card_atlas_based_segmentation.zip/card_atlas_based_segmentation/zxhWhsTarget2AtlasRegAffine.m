function succ=zxhWhsTarget2AtlasRegAffine(strTarget, strAtlasFilename, strLabelFilename, strPreSave, strType, args)  
% author: Xiahai Zhuang
% date of creation:   2015-6-03
% current version:  
%	succ=zxhWhsTarget2AtlasRegAffine(strTarget, strAtlasFilename, strLabelFilename, strPreSave, strType, args)  
%     Type: 
%        '-preaffine-'     (affine registration is pre-performed, from atlas to image, affine=args) 
%        '-preseg-'        (label images used for affine reg, init for global affine registration, preseg=args) 
%        '-roi-'           (roi of target image, used for init in global affine registration, roi=args) 
%        '-cc-'            (cross correlation as similarity)  
%        '-atlas2target-'  (generate affine from atlas to target)'
  preaffine=' ';    metric=' -MIIB 5 -200 1800 ' ; verbose=' -v 0 '; imagetype='.nii.gz'; 
  if isempty(strfind(strType,'-preaffine-'))==0,
    preaffine=[' -pre 0 ' args] ;
  end
  if isempty(strfind(strType,'-cc-'))==0,
    metric=' -cc ' ;
  end
  
  LabelMask=[strPreSave '__Mask' imagetype];
  %system(['zxhtransform ' strLabelFilename ' -o ' LabelMask ' -resave -spacing 2 2 2 -nearest -v 0']); 
   system(['zxhtransform ' strLabelFilename ' -o ' LabelMask ' -resave -spacing 2 2 2 -nearest ']); 
  if isempty(strfind(strType,'-roi-'))==0, 
    system(['zxhInitPreTransform ' strPreSave '.AFF -aff -prealign ' LabelMask ' ' args ' 2 ']);
    preaffine=[' -pre 0 ' strPreSave '.AFF'] ; 
    command=['zxhreg -test ' strAtlasFilename ' -ref ' strTarget ' -o ' strPreSave ' -notsaveimage -sub 6 6 6 -sub 5 5 5 -sub 4 4 4 ' ...  
             '-Reg 3 -length 3 2 1 -steps 200 100 50 ' metric  ' -maskt ' LabelMask ' -masktdi 20 -aff ' preaffine verbose]; 
    if isempty(strfind(strType,'-fast-'))==0, 
      command=['zxhreg -test ' strAtlasFilename ' -ref ' strTarget ' -o ' strPreSave ' -notsaveimage -sub 6 6 6 -sub 5 5 5 ' ...  
             '-Reg 2 -length 3 2 -steps 200 100 ' metric  ' -maskt ' LabelMask ' -masktdi 20 -aff ' preaffine verbose]; 
    end
    system(command);      
  elseif isempty(strfind(strType,'-preseg-'))==0, 
    TargetLabel=[strPreSave '__Mask2' imagetype];
    system(['zxhtransform ' args ' -o ' TargetLabel ' -resave -spacing 2 2 2 -nearest -v 0']); 
     
    if isempty(strfind(strType,'-fast-'))==0, 
      system(['zxhreg -test ' LabelMask ' -ref ' TargetLabel ' -o ' strPreSave ' -notsaveimage -smoothr 2 -smootht 2 -aff -length 2 -sub 6 6 6 -steps 200 -v 0']);
      command=['zxhreg -test ' strAtlasFilename ' -ref ' strTarget ' -o ' strPreSave ' -pre 0 ' strPreSave '.AFF -maskt ' LabelMask  ' -masktdi 20 -sub 5 5 5 -aff -notsaveimage ' metric verbose];  
      system(command); 
    else
      system(['zxhreg -test ' LabelMask ' -ref ' TargetLabel ' -o ' strPreSave ' -notsaveimage -smoothr 2 -smootht 2 -aff -length 2 1 -sub 6 6 6 -sub 4 4 4 -steps 200 100 -Reg 2 -v 0']);
      command=['zxhreg -test ' strAtlasFilename ' -ref ' strTarget ' -o ' strPreSave ' -pre 0 ' strPreSave '.AFF -maskt ' LabelMask  ' -masktdi 20 -sub 4 4 4 -aff -notsaveimage ' metric verbose];  
      system(command); 
    end
    delete(TargetLabel);
  elseif isempty(strfind(strType,'-preaffine-'))==0,
    system(['zxhimageop ' LabelMask ' -DI 10 -v 0']);  % 20mm
    
    if isempty(strfind(strType,'-fast-'))==0,  
      command=['zxhreg -test ' strAtlasFilename ' -ref ' strTarget ' -o ' strPreSave ' -maskt ' LabelMask  ' -sub 5 5 5 -aff -notsaveimage ' preaffine metric verbose];  
      system(command);  
    else
      command=['zxhreg -test ' strAtlasFilename ' -ref ' strTarget ' -o ' strPreSave ' -maskt ' LabelMask  ' -sub 4 4 4 -aff -notsaveimage ' preaffine metric verbose];  
      system(command);  
    end
  else
    system(['zxhimageop ' LabelMask ' -DI 10 -v 0']);  % 20mm
    
    if isempty(strfind(strType,'-fast-'))==0, 
      command=['zxhreg -test ' strAtlasFilename ' -ref ' strTarget ' -o ' strPreSave ' -sub 6 6 6 -scale -length 4 -regular 1.05  -notsaveimage ' preaffine metric verbose];
      system(command);
      command=['zxhreg -test ' strAtlasFilename ' -ref ' strTarget ' -o ' strPreSave ' -pre 0 ' strPreSave '.AFF -maskt ' LabelMask ' -masktdi 20 '...
               ' -sub 5 5 5 -scale -length 3 -regular 1.05 1 -steps 50 -notsaveimage ' metric verbose];
      system(command);  
      command=['zxhreg -test ' strAtlasFilename ' -ref ' strTarget ' -o ' strPreSave ' -pre 0 ' strPreSave '.AFF -maskt ' LabelMask  ' -sub 5 5 5 -aff -notsaveimage ' metric verbose];  
      system(command);  
    else
      command=['zxhreg -test ' strAtlasFilename ' -ref ' strTarget ' -o ' strPreSave ' -sub 6 6 6 -scale -length 4 -regular 1.05  -notsaveimage ' preaffine metric verbose];
      system(command);
      command=['zxhreg -test ' strAtlasFilename ' -ref ' strTarget ' -o ' strPreSave ' -pre 0 ' strPreSave '.AFF -maskt ' LabelMask ' -masktdi 20 '...
               ' -sub 5 5 5 -scale -length 3 1 -regular 1.05 1 -steps 50 200 -Reg 2  -notsaveimage ' metric verbose];
      system(command);  
      command=['zxhreg -test ' strAtlasFilename ' -ref ' strTarget ' -o ' strPreSave ' -pre 0 ' strPreSave '.AFF -maskt ' LabelMask  ' -sub 4 4 4 -aff -notsaveimage ' metric verbose];  
      system(command);   
    end
  end 
  if isempty(strfind(strType,'-atlas2target-'))~=0, % want target to atlas
    system(['zxhtransformvector ' LabelMask ' -o ' strPreSave '.AFF -inv 1 -n 1 -t ' strPreSave '.AFF -v 0 ']);
  end 
  delete(LabelMask);
  succ=[strPreSave '.AFF'];
end 
 











 