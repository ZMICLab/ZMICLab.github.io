function succ=zxhWhsGenLocRegion(strLabelFilename, strPreSave)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% author: Xiahai Zhuang
% date of creation:   2014-11
% current version: 2.0 (2015-07-20 validated code)
%                  local regions do not require much erosion due to usage of classam
%  succ=zxhGenLocRegion(strLabelFilename, strPreSave)
%  usage 1: generate local region files
%  usage 2: clear all local files zxhGenLocRegion('-clear-', strPreSave);
%  local files: 
%    U={save 'U.' imagetype] ;  D={save 'D.' imagetype] ; LV={save 'LV.' imagetype] ; RV={save 'RV.' imagetype] ; LU={save 'LU.' imagetype] ; WH={save 'WH.' imagetype] 
%    LA={save 'LA.' imagetype]; RA={save 'RA.' imagetype]; LO={save 'LO.' imagetype] ; RP={save 'RP.' imagetype] ; DO={save 'DO.' imagetype] ; 
%    FFDsMaskBlood={save 'MaskForFFDsBlood.' imagetype]; FFDsMaskFiner={save 'MaskForFFDsFiner.' imagetype]  ; Mask={save 'Mask.' imagetype] ; MaskWH={save 'MaskWH.' imagetype];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

imagetype='nii.gz' ; verbose=' -v 0 ' ;  atlastype='atlas' ;
% update history:  
% 		2012-05-29:  U = U + (DO+RP -dilted D)
%					1) U,D -sub -OP -CL 2) LA RA LO RP DO (-sub D(-DI 3)), RV LV (-sub U(-DI 7)) 3) local region exclude
%       2013-01: generate local regions for LARM2(DO, WH); LARM3(DO, U, D); LARM7; Make a zxhGenLocRegion2.sh
%                                            WH = All - DO - dilated DO ;  U = LA + RA + RP AO -dilted D 
%                  DO will be only considered in LARM
%       2013-04: MaskForFFDsFiner: boundary(exclude DO) di-10mm; for atlas label with liver (100), minus liver, for ccta (for cmr should be different, as RV is bright)

label=strLabelFilename ; save=strPreSave ;
WH=[save 'WH.' imagetype] ; LO=[save 'LO.' imagetype] ;
U=[save 'U.' imagetype] ;  D=[save 'D.' imagetype] ; 
LV=[save 'LV.' imagetype] ; RV=[save 'RV.' imagetype] ;  
LA=[save 'LA.' imagetype]; RA=[save 'RA.' imagetype];  RP=[save 'RP.' imagetype] ; DO=[save 'DO.' imagetype] ; 

FFDsMaskBlood=[save 'MaskForFFDsBlood.' imagetype]; 
FFDsMaskFiner=[save 'MaskForFFDsFiner.' imagetype] ;
Mask=[save 'Mask.' imagetype] ; %MaskWH=[save 'MaskWH.' imagetype];

%%%%% clear images'
if strcmp(label, '-clear-')==1 ,  
 delete(U, D, LV, RV) ;
 delete(LA, RA, LO, RP, DO);
 delete(WH, FFDsMaskBlood, FFDsMaskFiner, Mask);
% disp( 'Finish -- clear generated local regions'); 
 succ='success';
 return ;
end
sepatlas='204'; sepgd='304'; sepaachen='18';
myoatlas='205'; myogd='305'; myoaachen='18'; 
laatlas='420'; lagd='700'; laaachen='36'; 
lvatlas='500'; lvgd='780'; lvaachen='34';
loatlas='820'; logd='820'; loaachen='64'; lo1='821';
doatlas='822'; dogd='822'; doaachen='64'; 
do2atlas='823'; do2gd='823'; do2aachen='64';
pv1atlas='660'; pv1gd='660'; pv1aachen='76'; 
pv2atlas='670'; pv2gd='670'; pv2aachen='77'; 
pv3atlas='680'; pv3gd='680'; pv3aachen='78'; 
pv4atlas='690'; pv4gd='690'; pv4aachen='79'; 
raatlas='550'; ragd='750'; raaachen='38';
rvatlas='600'; rvgd='800'; rvaachen='35'; 
rpatlas='850'; rpgd='850'; rpaachen='71';
%'RP bifurcation: 851                    851                0'
ivcatlas='759'; ivcgd='759'; ivcaachen='69';
svcatlas='758'; svcgd='758'; svcaachen='68';
%'some coronary artery: 70               70                 70'
liver='100';  
 
if strcmp(atlastype,'gd')==1 , 
    sep=sepgd; myo=myogd; la=lagd; lv=lvgd; lo=logd; do=dogd;  do2=do2gd; pv1=pv1gd; pv2=pv2gd; pv3=pv3gd; pv4=pv4gd; ra=ragd; rv=rvgd; rp=rpgd; ivc=ivcgd; svc=svcgd;
else if strcmp(atlastype,'aachen')==1 , 
        sep=sepaachen; myo=myoaachen; la=laaachen; lv=lvaachen; lo=loaachen; do=doaachen;do2=do2aachen; pv1=pv1aachen; pv2=pv2aachen; pv3=pv3aachen; pv4=pv4aachen; ra=raaachen; rv=rvaachen; rp=rpaachen; ivc=ivcaachen; svc=svcaachen;
    else 
        sep=sepatlas; myo=myoatlas; la=laatlas; lv=lvatlas; lo=loatlas; do=doatlas; do2=do2atlas; pv1=pv1atlas; pv2=pv2atlas; pv3=pv3atlas; pv4=pv4atlas; ra=raatlas; rv=rvatlas; rp=rpatlas; ivc=ivcatlas; svc=svcatlas;
    end ; 
end 
rpb='851'; sca='70'; 

command=['zxhtransform ' label ' -o ' save '_atlas.' imagetype ' -resave -spacing 2 2 2 -nearest ' verbose]; system(command);
label=[save '_atlas.' imagetype] ;
command=['zxhimageop -int ' save '_atlas.' imagetype ' -o ' save '_liver.' imagetype ' -vr ' liver ' ' liver ' -VS ' liver verbose]; system(command); 
command=['zxhimageop -int ' save '_atlas.' imagetype ' -vr ' liver ' ' liver ' -vs 0 ' verbose]; system(command); 

% new-untested: mask = label+DI20mm, maskaff = WH +DI10mm, MaskForFFDsBlood=BloodExcludingDO, FFDsMaskFiner=Boundary_of_MaskForFFDsBlood+DI10mm,
command=['zxhimageop -int ' save '_atlas.' imagetype ' -o ' WH ' -vr 0 ' liver ' -vr ' do ' ' do2  ' -vs 0 ' verbose]; system(command);
command=['zxhimageop -int ' save '_atlas.' imagetype ' -o ' Mask ' -vr 200 1111 -VS 100 ' verbose]; system(command);
command=['zxhimageop -int ' Mask ' -o ' Mask ' -DI 10 ' verbose]; system(command);
command=['zxhimageop -int ' save '_atlas.' imagetype ' -o ' FFDsMaskBlood ' -vr 821 825 -vr 200 250 -vs 0 ' verbose]; system(command);
command=['zxhimageop -int ' FFDsMaskBlood ' -CL 7 ' verbose]; system(command);
command=['zxhimageop -int ' save '_atlas.' imagetype ' -o ' FFDsMaskFiner ' -vr 821 825 -vr 851 855 -vs 0 ' verbose]; system(command);
command=['zxhimageop -int ' FFDsMaskFiner ' -vr ' lv ' ' lv ' -vr ' la ' ' la ' -vr ' lo ' ' lo ' -vs ' lv verbose]; system(command);
command=['zxhimageop -int ' FFDsMaskFiner ' -vr ' rv ' ' rv ' -vr ' ra ' ' ra ' -vr ' rp ' ' rp ' -vs ' rv verbose]; system(command);
command=['zxhboundary -i ' FFDsMaskFiner ' -o ' FFDsMaskFiner ' ' verbose]; system(command);
command=['zxhimageop -int ' FFDsMaskFiner ' -o ' FFDsMaskFiner ' -DI 3 ' verbose]; system(command);  

command=['zxhimageop -int ' save '_liver.' imagetype ' -CL 5 ' verbose]; system(command); 
command=['zxhimageop -int ' FFDsMaskFiner ' -int ' save '_liver.' imagetype ' -o ' FFDsMaskFiner ' -sub ' verbose]; system(command); 
delete([save '_liver.' imagetype]); 


 % WH and DO
command=['zxhimageop -int ' label ' -o ' DO ' -vr ' do ' ' do2 ' -VS 1 ' verbose]; system(command);  
command=['zxhimageop -int ' DO ' -o ' save '_test.' imagetype ' -DI 4 ' verbose]; system(command) ; 
command=['zxhimageop -int ' WH ' -o ' save '_test1.' imagetype ' -DI 4 ' verbose]; system(command) ; 
command=['zxhimageop -int ' WH ' -int ' save '_test.' imagetype ' -o ' WH ' -sub -protect 2 ' verbose]; system(command);
command=['zxhimageop -int ' DO ' -int ' save '_test1.' imagetype ' -o ' DO ' -sub -protect 2 ' verbose]; system(command);

 % U and D (lv/rv) and DO
command=['zxhimageop -int ' label ' -o ' U ' -vr ' lv ' ' lv ' -vr ' rv ' ' rv ' -vr ' sep ' ' myo ' -vr ' lo1 ' ' do2 ' -vs 0 ' verbose]; system(command);
command=['zxhimageop -int ' label ' -o ' D ' -vr ' la ' ' la ' -vr ' pv1 ' ' pv4 ' -vr ' sca ' ' sca ' -vr ' ra ' ' ra ... 
    ' -vr ' lo ' ' do2 ' -vr ' rp ' ' rpb ' -vr ' svc ' ' ivc ' -vs 0 ' verbose]; system(command);
adi= '3'; a={ U, D, DO };
commands={[' -vr ' lv ' ' lv ' -vr ' rv ' ' rv ' -vr ' sep ' ' myo ' -vr ' lo1 ' ' do2 ' -vs 0 '], ...
   [' -vr ' la ' ' la ' -vr ' pv1 ' ' pv4 ' -vr ' sca ' ' sca ' -vr ' ra ' ' ra ' -vr ' lo ' ' do2 ' -vr ' rp ' ' rpb ' -vr ' svc ' ' ivc ' -vs 0 '], ...
   [' -vr ' do ' ' do2 ' -VS 1 ']};
for aid1=1:3 
  system(['zxhimageop -int ' label ' -o ' save '_test.' imagetype ' ' commands{aid1} verbose]);
  command=['zxhimageop -int ' save '_test.' imagetype ' -DI ' adi ' ' verbose]; system(command); 
  for aid2=1:2
    if aid1==aid2, continue ; end
    command=['zxhimageop -int ' a{aid2} ' -o ' a{aid2} ' -int ' save '_test.' imagetype ' -sub -protect 2 ' verbose]; system(command); 
  end
end 
command=['zxhimageop -int ' U ' -OP 3 -protect 2 ' verbose]; system(command);
command=['zxhimageop -int ' D ' -OP 3 -protect 2 ' verbose]; system(command);
command=['zxhimageop -int ' U ' -CL 5 ' verbose]; system(command);
command=['zxhimageop -int ' D ' -CL 5 ' verbose]; system(command);

 % 6 loc
command=['zxhimageop -int ' label ' -o ' LA ' -vr ' la ' ' la ' -VS 1 ' verbose]; system(command); 
command=['zxhimageop -int ' label ' -o ' LV ' -vr ' lv ' ' lv ' -VS 1 ' verbose]; system(command);
command=['zxhimageop -int ' label ' -o ' RA ' -vr ' ra ' ' ra ' -VS 1 ' verbose]; system(command);   
command=['zxhimageop -int ' label ' -o ' RV ' -vr ' rv ' ' rv ' -VS 1 ' verbose]; system(command);   
command=['zxhimageop -int ' label ' -o ' LO ' -vr ' lo ' ' lo ' -VS 1 ' verbose]; system(command);  
command=['zxhimageop -int ' label ' -o ' RP ' -vr ' rp ' ' rp ' -vr ' rpb ' ' rpb ' -VS 1 ' verbose]; system(command);

a={ LA , LV, RA, RV, LO, RP, DO }; adi='3'; bsub=a ; 
commands={ [' -vr ' la ' ' la ' -VS 1 '], ...
           [' -vr ' lv ' ' lv ' -VS 1 '], ...
           [' -vr ' ra ' ' ra ' -VS 1 '], ...
           [' -vr ' rv ' ' rv ' -VS 1 '], ...
           [' -vr ' lo ' ' lo ' -VS 1 '], ...
           [' -vr ' rp ' ' rp ' -vr ' rpb ' ' rpb ' -VS 1 '], ...
           [' -vr ' do ' ' do2 ' -VS 1 ']};
for aid=1:7 
  system(['zxhimageop -int ' label ' -o ' save '_test.' imagetype ' ' commands{aid} verbose]);
  command=['zxhimageop -int ' save '_test.' imagetype ' -DI ' adi ' ' verbose]; system(command); 
  for bid=1:6
    if aid==bid, continue ; end
    command=['zxhimageop -int ' bsub{bid} ' -o ' bsub{bid} ' -int ' save '_test.' imagetype ' -sub -protect 2 ' verbose]; system(command); 
  end
end 
 
 
   
%echo ------------- generate D U LV LA LU LO DO RV RA RP


delete( [save '_test.' imagetype],[save '_test1.' imagetype], [save '_atlas.' imagetype]);








