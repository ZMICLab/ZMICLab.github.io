
# all released gold standard segmentation of test data are encrypted. please use the "zxhCardMyoPSEvaluate" from zxhproj[1] to evaluate the Dice score of the pathologies. 
# e.g. for test_201, the obtained myops is myseg_201_result.nii.gz,
zxhCardMyoPSEvaluate.exe -evaps myops_test_201_gdencrypt.nii.gz myseg_201_result.nii.gz 1

success: open image myops_test_201_gdencrypt.nii.gz !
success: open image myseg_201_result.nii.gz !
dice_scar        dice_edemascar
0.920000        0.925000




[1] http://www.sdspeople.fudan.edu.cn/zhuangxiahai/0/zxhproj/